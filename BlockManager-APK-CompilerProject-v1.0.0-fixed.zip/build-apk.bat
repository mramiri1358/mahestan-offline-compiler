@echo off
echo ====================================================
echo Building Android APK for مدیریت بلوک (com.block.manager)
echo ====================================================
cd android-studio-project
call gradlew.bat assembleDebug
echo.
echo APK generated at: android-studio-project\app\build\outputs\apk\debug\app-debug.apk
pause