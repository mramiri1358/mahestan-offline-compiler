============================================================
پکیج کامل ساخت APK اندروید - مدیریت بلوک (نسخه 1.0.0)
شناسه پکیج: com.block.manager
============================================================

این فایل فشرده شامل ۳ روش استاندارد برای کامپایل و ساخت فایل نصبی APK واقعی است:

روش ۱ (سریع‌ترین - Android Studio):
پوشه "android-studio-project" یک پروژه کامل و آماده اندروید استودیو به همراه WebView تنظیم‌شده با فعال‌سازی کامل LocalStorage و JavaScript است.
- پوشه android-studio-project را در Android Studio باز کنید.
- از منوی Build گزینه Build Bundle(s) / APK(s) -> Build APK(s) را بزنید.

روش ۲ (استفاده از Cordova یا Capacitor):
- در ریشه پروژه فایل‌های package.json، capacitor.config.json و config.xml قرار دارند.
- دستور: npm install && npx cap sync android && npx cap open android

روش ۳ (استفاده از نرم‌افزار Website 2 APK Builder یا PWABuilder):
- محتویات پوشه "www" (یا فایل index.html در ریشه) را در برنامه Website 2 APK Builder قرار داده و دکمه Generate APK را بزنید.